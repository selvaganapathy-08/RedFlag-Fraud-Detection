-- =====================================================================
-- RedFlag — Fraud Detection Submission
-- Student: Rahul S. Ganapathy | Batch: DA-DS-1
-- =====================================================================

USE redflag;

-- =====================================================================
-- PATTERN 1: VELOCITY FRAUD
-- Look for users making 30 or more transactions on the same day.
-- =====================================================================

SELECT
    user_id,
    DATE(txn_time) AS attack_date,
    COUNT(*) AS daily_txn_count
FROM transactions
GROUP BY user_id, DATE(txn_time)
HAVING COUNT(*) >= 30
ORDER BY daily_txn_count DESC, user_id;

-- Findings: Review returned users as suspected high-velocity accounts.


-- =====================================================================
-- PATTERN 2: ROUND-AMOUNT CLUSTERING
-- Look for users making 15 or more transactions at common round amounts.
-- =====================================================================

SELECT
    user_id,
    COUNT(*) AS round_amount_txns,
    SUM(amount) AS total_round_amount
FROM transactions
WHERE amount IN (100, 200, 500, 1000, 2000, 5000, 10000)
GROUP BY user_id
HAVING COUNT(*) >= 15
ORDER BY round_amount_txns DESC, user_id;

-- Findings: Review users with repeated round-value transactions.


-- =====================================================================
-- PATTERN 3: CARD TESTING
-- Look for users making 30 or more transactions below Rs.10 on one day.
-- =====================================================================

SELECT
    user_id,
    DATE(txn_time) AS attack_date,
    COUNT(*) AS tiny_txn_count
FROM transactions
WHERE amount < 10
GROUP BY user_id, DATE(txn_time)
HAVING COUNT(*) >= 30
ORDER BY tiny_txn_count DESC, user_id;

-- Findings: Review high-frequency low-value transaction activity.


-- =====================================================================
-- PATTERN 4: FAILED-THEN-SUCCEEDED
-- Look for 20 or more failed transactions followed by a same-amount
-- successful transaction within 2 minutes for the same user.
-- =====================================================================

WITH failed_followed_by_success AS (
    SELECT
        f.user_id,
        f.txn_id AS failed_txn_id,
        f.txn_time AS failed_time,
        f.amount
    FROM transactions f
    WHERE f.status = 'FAILED'
      AND EXISTS (
          SELECT 1
          FROM transactions s
          WHERE s.user_id = f.user_id
            AND s.status = 'SUCCESS'
            AND s.amount = f.amount
            AND s.txn_time > f.txn_time
            AND s.txn_time <= f.txn_time + INTERVAL 2 MINUTE
      )
)
SELECT
    user_id,
    COUNT(*) AS failed_success_pairs
FROM failed_followed_by_success
GROUP BY user_id
HAVING COUNT(*) >= 20
ORDER BY failed_success_pairs DESC, user_id;

-- Findings: Review users with repeated failed-then-successful attempts.


-- =====================================================================
-- PATTERN 5: ODD-HOUR CONCENTRATION
-- Look for users with 30+ transactions where at least 80% occur
-- between 2 AM and 4 AM.
-- =====================================================================

SELECT
    user_id,
    COUNT(*) AS total_txns,
    SUM(
        CASE
            WHEN HOUR(txn_time) BETWEEN 2 AND 4 THEN 1
            ELSE 0
        END
    ) AS odd_hour_txns,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN HOUR(txn_time) BETWEEN 2 AND 4 THEN 1
                ELSE 0
            END
        ) / COUNT(*), 2
    ) AS odd_hour_percentage
FROM transactions
GROUP BY user_id
HAVING COUNT(*) >= 30
   AND SUM(
       CASE
           WHEN HOUR(txn_time) BETWEEN 2 AND 4 THEN 1
           ELSE 0
       END
   ) / COUNT(*) >= 0.80
ORDER BY odd_hour_percentage DESC, total_txns DESC;

-- Findings: Review users with unusually concentrated overnight activity.


-- =====================================================================
-- PATTERN 6: MULE ACCOUNTS
-- Look for 5 or more cases where a NETBANKING credit is followed within
-- 30 minutes by a UPI debit of at least 70% of the credited amount.
-- =====================================================================

SELECT
    c.user_id,
    COUNT(*) AS rapid_in_out_instances
FROM transactions c
WHERE c.txn_type = 'CREDIT'
  AND c.payment_mode = 'NETBANKING'
  AND EXISTS (
      SELECT 1
      FROM transactions d
      WHERE d.user_id = c.user_id
        AND d.txn_type = 'DEBIT'
        AND d.payment_mode = 'UPI'
        AND d.txn_time > c.txn_time
        AND d.txn_time <= c.txn_time + INTERVAL 30 MINUTE
        AND d.amount >= 0.70 * c.amount
  )
GROUP BY c.user_id
HAVING COUNT(*) >= 5
ORDER BY rapid_in_out_instances DESC, user_id;

-- Findings: Review users showing repeated rapid credit-to-debit movement.


-- =====================================================================
-- PATTERN 7: REFUND ABUSE
-- Look for users with 20+ total transactions and a refund ratio above 40%.
-- =====================================================================

SELECT
    user_id,
    COUNT(*) AS total_txns,
    SUM(
        CASE
            WHEN txn_type = 'REFUND' THEN 1
            ELSE 0
        END
    ) AS refund_txns,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN txn_type = 'REFUND' THEN 1
                ELSE 0
            END
        ) / COUNT(*), 2
    ) AS refund_percentage
FROM transactions
GROUP BY user_id
HAVING COUNT(*) >= 20
   AND SUM(
       CASE
           WHEN txn_type = 'REFUND' THEN 1
           ELSE 0
       END
   ) / COUNT(*) > 0.40
ORDER BY refund_percentage DESC, total_txns DESC;

-- Findings: Review users with unusually high refund activity.


-- =====================================================================
-- PATTERN 8: MERCHANT COLLUSION
-- Look for merchants where the top 5 users by transaction volume
-- account for more than 60% of the merchant's total amount.
-- =====================================================================

WITH user_merchant_volume AS (
    SELECT
        merchant_id,
        user_id,
        SUM(amount) AS user_volume
    FROM transactions
    GROUP BY merchant_id, user_id
),
ranked_users AS (
    SELECT
        merchant_id,
        user_id,
        user_volume,
        ROW_NUMBER() OVER (
            PARTITION BY merchant_id
            ORDER BY user_volume DESC, user_id
        ) AS user_rank
    FROM user_merchant_volume
),
merchant_totals AS (
    SELECT
        merchant_id,
        SUM(amount) AS merchant_total
    FROM transactions
    GROUP BY merchant_id
),
top_five AS (
    SELECT
        merchant_id,
        SUM(user_volume) AS top_five_volume
    FROM ranked_users
    WHERE user_rank <= 5
    GROUP BY merchant_id
)
SELECT
    t.merchant_id,
    t.top_five_volume,
    m.merchant_total,
    ROUND(
        100.0 * t.top_five_volume / m.merchant_total, 2
    ) AS top_five_percentage
FROM top_five t
JOIN merchant_totals m
    ON m.merchant_id = t.merchant_id
WHERE t.top_five_volume / m.merchant_total > 0.60
ORDER BY top_five_percentage DESC, t.merchant_id;

-- Findings: Review merchants with highly concentrated user activity.


-- =====================================================================
-- PATTERN 9: JUST-UNDER-THRESHOLD / STRUCTURING
-- Look for users making 10 or more transactions exactly at Rs.9,999.
-- =====================================================================

SELECT
    user_id,
    COUNT(*) AS threshold_avoiding_txns,
    SUM(amount) AS total_amount
FROM transactions
WHERE amount = 9999.00
GROUP BY user_id
HAVING COUNT(*) >= 10
ORDER BY threshold_avoiding_txns DESC, user_id;

-- Findings: Review users repeatedly using the Rs.9,999 threshold amount.


-- =====================================================================
-- PATTERN 10: DORMANT-THEN-ACTIVE
-- Look for a 90+ day gap followed by at least 15 later transactions.
-- =====================================================================

WITH transaction_gaps AS (
    SELECT
        user_id,
        txn_id,
        txn_time,
        LAG(txn_time) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_txn_time
    FROM transactions
),
dormant_accounts AS (
    SELECT
        user_id,
        txn_time AS reactivation_time,
        previous_txn_time
    FROM transaction_gaps
    WHERE previous_txn_time IS NOT NULL
      AND TIMESTAMPDIFF(
          DAY, previous_txn_time, txn_time
      ) >= 90
),
post_gap_activity AS (
    SELECT
        d.user_id,
        d.reactivation_time,
        COUNT(t.txn_id) AS post_gap_txns
    FROM dormant_accounts d
    JOIN transactions t
        ON t.user_id = d.user_id
       AND t.txn_time >= d.reactivation_time
    GROUP BY d.user_id, d.reactivation_time
)
SELECT
    user_id,
    MAX(post_gap_txns) AS max_post_gap_txns
FROM post_gap_activity
GROUP BY user_id
HAVING MAX(post_gap_txns) >= 15
ORDER BY max_post_gap_txns DESC, user_id;

-- Findings: Review accounts that became active after a long dormant period.


-- =====================================================================
-- PATTERN 11: VELOCITY SPIKE
-- Look for users whose peak monthly transaction count is at least
-- 5 times their average monthly count and the peak is at least 20.
-- =====================================================================

WITH monthly_counts AS (
    SELECT
        user_id,
        DATE_FORMAT(txn_time, '%Y-%m') AS txn_month,
        COUNT(*) AS monthly_txn_count
    FROM transactions
    GROUP BY user_id, DATE_FORMAT(txn_time, '%Y-%m')
),
user_monthly_stats AS (
    SELECT
        user_id,
        AVG(monthly_txn_count) AS avg_monthly_txns,
        MAX(monthly_txn_count) AS peak_monthly_txns
    FROM monthly_counts
    GROUP BY user_id
)
SELECT
    user_id,
    ROUND(avg_monthly_txns, 2) AS avg_monthly_txns,
    peak_monthly_txns,
    ROUND(
        peak_monthly_txns / avg_monthly_txns, 2
    ) AS spike_ratio
FROM user_monthly_stats
WHERE peak_monthly_txns >= 20
  AND peak_monthly_txns / avg_monthly_txns >= 5
ORDER BY spike_ratio DESC, peak_monthly_txns DESC;

-- Findings: Review users with sudden monthly transaction spikes.


-- =====================================================================
-- PATTERN 12: GEOGRAPHIC IMPOSSIBILITY
-- Look for consecutive transactions by the same user in different
-- cities within 60 minutes.
-- =====================================================================

WITH transaction_sequence AS (
    SELECT
        user_id,
        txn_id,
        txn_time,
        city,
        LAG(txn_time) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_txn_time,
        LAG(city) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_city
    FROM transactions
)
SELECT
    user_id,
    txn_id,
    previous_city,
    city AS current_city,
    previous_txn_time,
    txn_time,
    TIMESTAMPDIFF(
        MINUTE, previous_txn_time, txn_time
    ) AS minutes_apart
FROM transaction_sequence
WHERE previous_city IS NOT NULL
  AND previous_city <> city
  AND TIMESTAMPDIFF(
      MINUTE, previous_txn_time, txn_time
  ) <= 60
ORDER BY minutes_apart ASC, user_id, txn_time;

-- Findings: Review users with rapid location changes between transactions.

-- =====================================================================
-- END OF REDFLAG FRAUD DETECTION SUBMISSION
-- =====================================================================
